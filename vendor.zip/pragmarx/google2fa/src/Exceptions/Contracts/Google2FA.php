<?php

namespace PragmaRX\Google2FA\Exceptions\Contracts;

use Throwable;

interface Google2FA extends Throwable
{
}
