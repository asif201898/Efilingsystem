<?php

namespace PragmaRX\Google2FA\Exceptions\Contracts;

use Throwable;

interface InvalidCharacters extends Throwable
{
}
